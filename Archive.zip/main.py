import player as p
import board
import random
plr=[]
pos=[]
b=board.board()
a= int(input("\nenter number of players"))
for i in range(1,a+1):
    plr.append(p.player(i))
    plr[i-1].position=0

for i in range(1,11):
    for j in plr:
        r = random.randrange(2, 12)
        pos=j.position
        pos+=r
        if pos >=38:
            pos -= 39
        j.position=pos
        print("dice moves:", r, " player", j.id, "position:", pos)
        b.play(j, pos)


for i in range(0,a):
    print("player:",plr[i].id,"ammount is:",plr[i].ammount)



