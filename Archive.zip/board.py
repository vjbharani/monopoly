class board:
    def __init__(self):
        self._hotel=[{2:0},{9:0},{19:0},{32:0}]
        self.treasure=[33,22,12,3]
        self.jail=[35,26,17,6]
    def play(self,player,pos):
        for i in self._hotel:
            if pos in i.keys():
                if i.get(pos)==0:
                    newdict={pos:player.id}
                    i.update(newdict)
                    ammount=player.ammount
                    ammount-=200
                    player.ammount=ammount
                    player.hotelid=pos
                elif i.get(pos)!=0:
                    ammount = player.ammount
                    ammount-=50
                    player.ammount=ammount

        if pos in self.treasure:
            ammount = player.ammount
            ammount+=200
            player.ammount=ammount
        if pos in self.jail:
            ammount = player.ammount
            ammount -= 150
            player.ammount=ammount
        else:
            pass






